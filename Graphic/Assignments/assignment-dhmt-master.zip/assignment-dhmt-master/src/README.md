# Run
## ```Make ass && ./a```

